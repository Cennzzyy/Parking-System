export const calculatePrice = (durationHours: number): number => {
  const HOURLY_RATE = 10;
  return durationHours * HOURLY_RATE;
};

export const formatPrice = (price: number): string => {
  return `$${price.toFixed(2)}`;
};