import { create } from 'zustand';
import { ParkingSpot, Reservation } from '../types/parking';

interface ParkingStore {
  spots: ParkingSpot[];
  reservations: Reservation[];
  selectedSpot: ParkingSpot | null;
  setSelectedSpot: (spot: ParkingSpot | null) => void;
  makeReservation: (reservation: Omit<Reservation, 'id'>) => void;
}

export const useParkingStore = create<ParkingStore>((set) => ({
  spots: generateInitialSpots(),
  reservations: [],
  selectedSpot: null,
  setSelectedSpot: (spot) => set({ selectedSpot: spot }),
  makeReservation: (reservation) => {
    const newReservation = {
      ...reservation,
      id: Math.random().toString(36).substr(2, 9),
    };
    set((state) => ({
      reservations: [...state.reservations, newReservation],
      spots: state.spots.map((spot) =>
        spot.id === reservation.spotId
          ? { ...spot, status: 'reserved' }
          : spot
      ),
    }));
  },
}));

function generateInitialSpots(): ParkingSpot[] {
  const spots: ParkingSpot[] = [];
  for (let level = 1; level <= 2; level++) {
    for (let i = 1; i <= 20; i++) {
      const type = i <= 2 ? 'handicap' : i <= 4 ? 'ev' : 'standard';
      spots.push({
        id: `${level}-${i}`,
        number: `${level}${i.toString().padStart(2, '0')}`,
        status: Math.random() > 0.3 ? 'available' : 'occupied',
        type,
        level,
      });
    }
  }
  return spots;
}