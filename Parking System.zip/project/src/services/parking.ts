import api from './api';
import type { ParkingSpot, Reservation } from '../types/parking';

export const parkingService = {
  async getSpots() {
    const { data } = await api.get<ParkingSpot[]>('/parking');
    return data;
  },

  async updateSpotStatus(spotId: string, status: ParkingSpot['status']) {
    const { data } = await api.patch(`/parking/${spotId}/status`, { status });
    return data;
  },

  async createReservation(reservation: Omit<Reservation, 'id'>) {
    const { data } = await api.post('/reservations', reservation);
    return data;
  },

  async getUserReservations(userId: string) {
    const { data } = await api.get<Reservation[]>(`/reservations/user/${userId}`);
    return data;
  },

  async cancelReservation(reservationId: string) {
    const { data } = await api.patch(`/reservations/${reservationId}/cancel`);
    return data;
  },
};