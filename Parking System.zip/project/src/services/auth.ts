import api from './api';
import type { User } from '../types/auth';

export const authService = {
  async login(email: string, password: string) {
    const { data } = await api.post('/users/login', { email, password });
    localStorage.setItem('token', data.token);
    return data.user;
  },

  async register(email: string, password: string, name: string) {
    const { data } = await api.post('/users/register', { email, password, name });
    return data;
  },

  logout() {
    localStorage.removeItem('token');
  },
};