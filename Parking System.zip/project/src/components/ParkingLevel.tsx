import React from 'react';
import { ParkingSpot } from './ParkingSpot';
import { useParkingStore } from '../store/parkingStore';
import type { ParkingSpot as ParkingSpotType } from '../types/parking';

interface ParkingLevelProps {
  level: number;
}

export const ParkingLevel: React.FC<ParkingLevelProps> = ({ level }) => {
  const { spots, setSelectedSpot } = useParkingStore();
  const levelSpots = spots.filter((spot) => spot.level === level);

  return (
    <div className="mb-8">
      <h2 className="text-xl font-semibold mb-4">Level {level}</h2>
      <div className="flex flex-wrap gap-2">
        {levelSpots.map((spot) => (
          <ParkingSpot
            key={spot.id}
            spot={spot}
            onClick={(spot: ParkingSpotType) => setSelectedSpot(spot)}
          />
        ))}
      </div>
    </div>
  );
};