import React, { useState } from 'react';
import { format } from 'date-fns';
import { ParkingIcons } from './icons';
import { useParkingStore } from '../store/parkingStore';
import { calculatePrice, formatPrice } from '../utils/pricing';
import type { ParkingSpot } from '../types/parking';

interface ReservationModalProps {
  spot: ParkingSpot;
  onClose: () => void;
}

export const ReservationModal: React.FC<ReservationModalProps> = ({
  spot,
  onClose,
}) => {
  const [startTime, setStartTime] = useState<string>(
    format(new Date(), "yyyy-MM-dd'T'HH:mm")
  );
  const [duration, setDuration] = useState<number>(1);
  const { makeReservation } = useParkingStore();

  const handleReservation = () => {
    const start = new Date(startTime);
    const end = new Date(start.getTime() + duration * 60 * 60 * 1000);
    
    makeReservation({
      spotId: spot.id,
      startTime: start,
      endTime: end,
      status: 'active',
      price: calculatePrice(duration),
    });
    
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white rounded-lg p-6 w-96">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold">Reserve Spot {spot.number}</h3>
          <button onClick={onClose} className="p-1">
            <ParkingIcons.Close />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Start Time
            </label>
            <input
              type="datetime-local"
              value={startTime}
              onChange={(e) => setStartTime(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Duration (hours)
            </label>
            <select
              value={duration}
              onChange={(e) => setDuration(Number(e.target.value))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              {[1, 2, 3, 4, 5, 6].map((hours) => (
                <option key={hours} value={hours}>
                  {hours} {hours === 1 ? 'hour' : 'hours'}
                </option>
              ))}
            </select>
          </div>

          <div className="mt-4 text-right">
            <span className="mr-4">
              Total: {formatPrice(calculatePrice(duration))}
            </span>
            <button
              onClick={handleReservation}
              className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
            >
              Confirm Reservation
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};