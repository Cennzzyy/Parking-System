import React from 'react';
import { Link } from 'react-router-dom';
import { Car, Map, BarChart as ChartBar, Calendar } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { useParkingStore } from '../store/parkingStore';

export const Dashboard: React.FC = () => {
  const { user } = useAuthStore();
  const { spots } = useParkingStore();

  const availableSpots = spots.filter(spot => spot.status === 'available').length;
  const occupiedSpots = spots.filter(spot => spot.status === 'occupied').length;
  const reservedSpots = spots.filter(spot => spot.status === 'reserved').length;

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-4">
          {user ? `Welcome back, ${user.name}!` : 'Welcome to Smart Parking'}
        </h1>
        <p className="text-gray-600">
          Find and reserve your parking spot with ease.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-green-50 rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-600 text-sm font-medium">Available Spots</p>
              <p className="text-3xl font-bold text-green-700">{availableSpots}</p>
            </div>
            <Car className="w-8 h-8 text-green-500" />
          </div>
        </div>

        <div className="bg-red-50 rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-red-600 text-sm font-medium">Occupied Spots</p>
              <p className="text-3xl font-bold text-red-700">{occupiedSpots}</p>
            </div>
            <Car className="w-8 h-8 text-red-500" />
          </div>
        </div>

        <div className="bg-yellow-50 rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-yellow-600 text-sm font-medium">Reserved Spots</p>
              <p className="text-3xl font-bold text-yellow-700">{reservedSpots}</p>
            </div>
            <Calendar className="w-8 h-8 text-yellow-500" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Link
          to="/map"
          className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow"
        >
          <div className="flex items-center space-x-4">
            <Map className="w-6 h-6 text-blue-500" />
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Parking Map</h3>
              <p className="text-gray-600">View real-time parking availability</p>
            </div>
          </div>
        </Link>

        <Link
          to="/reservations"
          className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow"
        >
          <div className="flex items-center space-x-4">
            <Calendar className="w-6 h-6 text-purple-500" />
            <div>
              <h3 className="text-lg font-semibold text-gray-900">My Reservations</h3>
              <p className="text-gray-600">Manage your parking reservations</p>
            </div>
          </div>
        </Link>

        <Link
          to="/statistics"
          className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow"
        >
          <div className="flex items-center space-x-4">
            <ChartBar className="w-6 h-6 text-indigo-500" />
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Statistics</h3>
              <p className="text-gray-600">View parking usage analytics</p>
            </div>
          </div>
        </Link>
      </div>
    </div>
  );
};