import React from 'react';
import { ParkingLevel } from '../ParkingLevel';

export const ParkingMap: React.FC = () => {
  return (
    <div className="space-y-8">
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Parking Map</h2>
        <div className="space-y-12">
          <ParkingLevel level={1} />
          <ParkingLevel level={2} />
        </div>
      </div>
    </div>
  );
};