import React from 'react';
import { BarChart, Calendar, Clock, Wallet } from 'lucide-react';
import { useParkingStore } from '../../store/parkingStore';
import { calculatePrice } from '../../utils/pricing';

export const Statistics: React.FC = () => {
  const { reservations } = useParkingStore();

  const totalRevenue = reservations.reduce((sum, res) => sum + res.price, 0);
  const averageDuration = reservations.length
    ? reservations.reduce((sum, res) => {
        const duration = new Date(res.endTime).getTime() - new Date(res.startTime).getTime();
        return sum + duration / (1000 * 60 * 60);
      }, 0) / reservations.length
    : 0;

  const popularHours = Array.from({ length: 24 }, (_, hour) => ({
    hour,
    count: reservations.filter(res => new Date(res.startTime).getHours() === hour).length,
  }));

  const mostPopularHour = popularHours.reduce((max, curr) => 
    curr.count > max.count ? curr : max
  );

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Parking Statistics</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <Calendar className="w-8 h-8 text-blue-500" />
            <span className="text-sm font-medium text-gray-500">Total Reservations</span>
          </div>
          <p className="text-3xl font-bold text-gray-900">{reservations.length}</p>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <Clock className="w-8 h-8 text-green-500" />
            <span className="text-sm font-medium text-gray-500">Avg Duration</span>
          </div>
          <p className="text-3xl font-bold text-gray-900">
            {averageDuration.toFixed(1)}h
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <Wallet className="w-8 h-8 text-purple-500" />
            <span className="text-sm font-medium text-gray-500">Total Revenue</span>
          </div>
          <p className="text-3xl font-bold text-gray-900">${totalRevenue}</p>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <BarChart className="w-8 h-8 text-orange-500" />
            <span className="text-sm font-medium text-gray-500">Peak Hour</span>
          </div>
          <p className="text-3xl font-bold text-gray-900">
            {mostPopularHour.hour}:00
          </p>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Hourly Distribution</h3>
        <div className="h-64">
          <div className="flex h-full items-end space-x-2">
            {popularHours.map(({ hour, count }) => (
              <div
                key={hour}
                className="flex-1 bg-blue-100 hover:bg-blue-200 transition-colors rounded-t"
                style={{
                  height: `${(count / Math.max(...popularHours.map(h => h.count))) * 100}%`,
                }}
              >
                <div className="text-xs text-center mt-2">{hour}:00</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};