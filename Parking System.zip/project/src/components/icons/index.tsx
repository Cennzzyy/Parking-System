import React from 'react';
import { 
  CarFront, 
  Accessibility as AccessibilityIcon,
  Zap as ZapIcon,
  X as CloseIcon 
} from 'lucide-react';

export const ParkingIcons = {
  Standard: () => <CarFront className="w-6 h-6 text-gray-600" />,
  Handicap: () => <AccessibilityIcon className="w-6 h-6 text-blue-600" />,
  EV: () => <ZapIcon className="w-6 h-6 text-green-600" />,
  Close: () => <CloseIcon className="w-6 h-6" />
};