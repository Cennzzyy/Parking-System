import React from 'react';
import { ParkingIcons } from './icons';
import { ParkingSpot as ParkingSpotType } from '../types/parking';

interface ParkingSpotProps {
  spot: ParkingSpotType;
  onClick: (spot: ParkingSpotType) => void;
}

export const ParkingSpot: React.FC<ParkingSpotProps> = ({ spot, onClick }) => {
  const getSpotColor = () => {
    switch (spot.status) {
      case 'available':
        return 'bg-green-100 hover:bg-green-200';
      case 'occupied':
        return 'bg-red-100';
      case 'reserved':
        return 'bg-yellow-100';
      default:
        return 'bg-gray-100';
    }
  };

  const getIcon = () => {
    switch (spot.type) {
      case 'handicap':
        return <ParkingIcons.Handicap />;
      case 'ev':
        return <ParkingIcons.EV />;
      default:
        return <ParkingIcons.Standard />;
    }
  };

  return (
    <div
      onClick={() => spot.status === 'available' && onClick(spot)}
      className={`
        ${getSpotColor()}
        w-24 h-32 m-2 rounded-lg flex flex-col items-center justify-center
        cursor-pointer transition-colors duration-200
        ${spot.status === 'available' ? 'cursor-pointer' : 'cursor-not-allowed'}
      `}
    >
      {getIcon()}
      <span className="mt-2 font-medium">{spot.number}</span>
      <span className="text-xs capitalize mt-1">{spot.status}</span>
    </div>
  );
};