export interface ParkingSpot {
  id: string;
  number: string;
  status: 'available' | 'occupied' | 'reserved';
  type: 'standard' | 'handicap' | 'ev';
  level: number;
}

export interface ParkingLevel {
  level: number;
  spots: ParkingSpot[];
}

export interface Reservation {
  id: string;
  spotId: string;
  startTime: Date;
  endTime: Date;
  status: 'active' | 'completed' | 'cancelled';
  price: number;
}