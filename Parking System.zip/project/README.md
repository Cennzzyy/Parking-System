# Smart Parking System

## Setup Instructions

1. Install Dependencies:
   ```bash
   npm install
   ```

2. Database Setup:
   - Install MySQL if not already installed
   - Create a new database:
     ```sql
     CREATE DATABASE parking_system;
     ```
   - Update `.env` file with your MySQL credentials

3. Start the Application:
   - Open two terminals in VS Code
   - In the first terminal (Backend):
     ```bash
     npm run server
     ```
   - In the second terminal (Frontend):
     ```bash
     npm run dev
     ```

4. Access the Application:
   - Frontend: http://localhost:5173
   - Backend: http://localhost:3000

## Troubleshooting

If you encounter database connection issues:
1. Verify MySQL is running
2. Check credentials in `.env` match your MySQL setup
3. Ensure the database exists
4. Check MySQL user has proper permissions