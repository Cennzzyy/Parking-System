import express from 'express';
import { pool } from '../database/config.js';

const router = express.Router();

// Create new reservation
router.post('/', async (req, res) => {
  const { userId, spotId, startTime, endTime, price } = req.body;
  try {
    // Start transaction
    const connection = await pool.getConnection();
    await connection.beginTransaction();

    try {
      // Check if spot is available
      const [spot] = await connection.query(
        'SELECT status FROM parking_spots WHERE id = ? FOR UPDATE',
        [spotId]
      );

      if (spot[0].status !== 'available') {
        await connection.rollback();
        return res.status(400).json({ error: 'Spot is not available' });
      }

      // Create reservation
      const [result] = await connection.query(
        'INSERT INTO reservations (id, user_id, spot_id, start_time, end_time, price) VALUES (UUID(), ?, ?, ?, ?, ?)',
        [userId, spotId, startTime, endTime, price]
      );

      // Update spot status
      await connection.query(
        'UPDATE parking_spots SET status = ? WHERE id = ?',
        ['reserved', spotId]
      );

      await connection.commit();
      res.status(201).json({ id: result.insertId });
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  } catch (error) {
    res.status(500).json({ error: 'Error creating reservation' });
  }
});

// Get user's reservations
router.get('/user/:userId', async (req, res) => {
  try {
    const [reservations] = await pool.query(
      `SELECT r.*, p.number, p.level, p.type 
       FROM reservations r 
       JOIN parking_spots p ON r.spot_id = p.id 
       WHERE r.user_id = ?`,
      [req.params.userId]
    );
    res.json(reservations);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching reservations' });
  }
});

// Cancel reservation
router.patch('/:id/cancel', async (req, res) => {
  try {
    const connection = await pool.getConnection();
    await connection.beginTransaction();

    try {
      const [reservation] = await connection.query(
        'SELECT spot_id FROM reservations WHERE id = ?',
        [req.params.id]
      );

      await connection.query(
        'UPDATE reservations SET status = ? WHERE id = ?',
        ['cancelled', req.params.id]
      );

      await connection.query(
        'UPDATE parking_spots SET status = ? WHERE id = ?',
        ['available', reservation[0].spot_id]
      );

      await connection.commit();
      res.json({ message: 'Reservation cancelled successfully' });
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  } catch (error) {
    res.status(500).json({ error: 'Error cancelling reservation' });
  }
});

export const reservationRoutes = router;