import express from 'express';
import { pool } from '../database/config.js';

const router = express.Router();

// Get all parking spots
router.get('/', async (req, res) => {
  try {
    const [spots] = await pool.query('SELECT * FROM parking_spots');
    res.json(spots);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching parking spots' });
  }
});

// Get parking spot by id
router.get('/:id', async (req, res) => {
  try {
    const [spot] = await pool.query('SELECT * FROM parking_spots WHERE id = ?', [req.params.id]);
    if (spot.length === 0) {
      return res.status(404).json({ error: 'Parking spot not found' });
    }
    res.json(spot[0]);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching parking spot' });
  }
});

// Update parking spot status
router.patch('/:id/status', async (req, res) => {
  const { status } = req.body;
  try {
    await pool.query('UPDATE parking_spots SET status = ? WHERE id = ?', [status, req.params.id]);
    res.json({ message: 'Status updated successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Error updating parking spot status' });
  }
});

export const parkingRoutes = router;