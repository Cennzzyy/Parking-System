import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { parkingRoutes } from './routes/parking.js';
import { reservationRoutes } from './routes/reservations.js';
import { userRoutes } from './routes/users.js';
import { initializeDatabase } from './database/init.js';
import { pool } from './database/config.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Test database connection and initialize
async function startServer() {
  try {
    // Test database connection
    await pool.query('SELECT 1');
    console.log('Database connection successful');

    // Initialize database and tables
    await initializeDatabase();

    // Routes
    app.use('/api/parking', parkingRoutes);
    app.use('/api/reservations', reservationRoutes);
    app.use('/api/users', userRoutes);

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Error starting server:', error);
    process.exit(1);
  }
}

startServer();